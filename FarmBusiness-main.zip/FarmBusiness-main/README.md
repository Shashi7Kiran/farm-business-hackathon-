## FarmBusiness
The repository is for <strong>Hackmol 3.0</strong> dated from 26-27
 ### Team member
  <ul>
  <li>Shubham Kumar <strong>Team leader</strong></li>
     
  <li>Ankit Jha</li>
       
  
  <li>Anshul Sharma</li>
  
  <li>Harsh Dhiman</li>
  
   <li>Paras Gupta</li>
  
  </ul>
  
   ###  The idea behind the project is on this   [ppt](https://docs.google.com/presentation/d/1P77r3UcnPb-IerrsOJiK4A_6ZLH1UVL2/edit?usp=sharing&ouid=106774572943632079902&rtpof=true&sd=true).

  
<!--   ###Illustration of of our project -->
Tech Stack used is 
- HTML
- CSS
- JAVASCRIPT
- NODEJS
- MONGODB
- EJS
- EXPRESS JS
- BCRYPTJS
- AXIOS
- MONGOOSE
- SASS
- TAILWIND
- JSONWEBTOKEN

---
 Team details
- Team Code : 69e18d5e01
- Team Name : the_optimizers
- IsFresher: False

---

# Setup
Download [Node.js](https://nodejs.org/en/download/).
Run this followed commands:

``` bash
# Install dependencies (only the first time)
npm i
# Run the local server at localhost:8080
npm run start
```

---
## Images
<h3>HOME PAGE</h3>

![image](https://github.com/18ankitjha/FarmBusiness/blob/main/Web%20capture_27-2-2022_231919_localhost.jpeg)


<h3>SIGN UP PAGES</h3>

<h4>Farmer</h4>

![image](https://github.com/18ankitjha/FarmBusiness/blob/main/Web%20capture_27-2-2022_232132_localhost.jpeg)

<h4>Company</h4>

![image](https://github.com/18ankitjha/FarmBusiness/blob/main/Web%20capture_27-2-2022_232742_localhost.jpeg)


![image](https://github.com/18ankitjha/FarmBusiness/blob/main/Web%20capture_27-2-2022_232742_localhost.jpeg)


<h3>LOGIN PAGES</h3>

![image](https://github.com/18ankitjha/FarmBusiness/blob/main/Web%20capture_28-2-2022_01847_localhost.jpeg)


<h3>Dashboard</h3>

<h4>Farmer</h4>

![image](https://github.com/18ankitjha/FarmBusiness/blob/main/Web%20capture_27-2-2022_23241_localhost.jpeg)

<h4>Company</h4>


![image](https://github.com/18ankitjha/FarmBusiness/blob/main/Web%20capture_27-2-2022_232944_localhost.jpeg)

![image](https://github.com/18ankitjha/FarmBusiness/blob/main/Web%20capture_27-2-2022_23315_localhost.jpeg)

![image](https://github.com/18ankitjha/FarmBusiness/blob/main/Web%20capture_28-2-2022_01551_localhost.jpeg)

---
Video link/embed is 


- https://www.loom.com/share/30478e994cdd4abc8839bb44a0835876?sharedAppSource=personal_library

